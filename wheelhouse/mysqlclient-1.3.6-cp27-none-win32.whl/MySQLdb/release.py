
__author__ = "Andy Dustman <farcepest@gmail.com>"
version_info = (1,3,6,'final',1)
__version__ = "1.3.6"
